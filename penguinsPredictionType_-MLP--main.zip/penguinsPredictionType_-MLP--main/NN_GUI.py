import tkinter
import numpy as np
from tkinter import *
from MLP import *
from preprossing import *
import random
window = tkinter.Tk()
window.title("Task 3")
window.geometry('500x600')
frame = Frame(window)

layers = Label(window, height=2, width=20, text="Enter Hidden layers: ")
layers.config(font=('Serif', 15))
layers.place(x=10, y=50)
enter_layers = Entry(window)
enter_layers.config(font=('Serif', 12))
enter_layers.place(x=245, y=65)

nearons = Label(window, height=2, width=20, text="Enter number of neurons \nin each hidden layer: ")
nearons.config(font=('Serif', 15))
nearons.place(x=10, y=95)
enter_nearons = Entry(window)
enter_nearons.config(font=('Serif', 12))
enter_nearons.place(x=245, y=110)


def cellsPerLayer():
    cellsStr = enter_nearons.get().split()
    cellsNum = []  # input layer has 5 cells
    # cellsNum.append(5)
    for i in cellsStr:
        cellsNum.append(int(i))
    return cellsNum


def Select_function():
    i = 0
    if (tanh.get() == 1): i = i + 1
    if (sigmoid.get() == 1): i = i + 1
    if (i > 0):
        if (tanh.get() != 1):
            f1.config(state='disabled')
        if (sigmoid.get() != 1):
            f2.config(state='disabled')
    else:
        f1.config(state='normal')
        f2.config(state='normal')


function = Label(window, height=2, width=20, text="Select Function: ")
function.config(font=('Serif', 15))
function.place(x=10, y=170)

sigmoid = IntVar(window)
tanh = IntVar(window)
f1 = Checkbutton(window, text='Tanh', command=Select_function, variable=tanh)
f1.config(font=('Serif', 12))
f2 = Checkbutton(window, text='Sigmoid', command=Select_function, variable=sigmoid)
f2.config(font=('Serif', 12))
f1.place(x=235, y=165)
f2.place(x=235, y=195)

eta = Label(window, height=2, width=20, text="Enter learning rate: ")
eta.config(font=('Serif', 15))
eta.place(x=10, y=230)
enter_eta = Entry(window)
enter_eta.config(font=('Serif', 12))
enter_eta.place(x=245, y=247)
epochs = Label(window, height=2, width=20, text="Enter number of epochs: ")
epochs.config(font=('Serif', 15))
epochs.place(x=10, y=280)
epNum = IntVar()
epochsNum = Entry(window)
epochsNum.config(font=('Serif', 12))
epochsNum.place(x=245, y=295)

CheckVar1 = IntVar()
biasNum = 0
C1 = Checkbutton(window, text="bias", variable=CheckVar1)
C1.config(font=('Serif', 15))
C1.place(x=50, y=330)
if CheckVar1.get() == 1:
    biasNum = np.random.random(0, 1)
else:
    biasNum = 0

def convertY(y_pred,c):
    y_predection_col = []
    
    for j in range(len(y_pred)):
        max_value = y_pred[j][0]
        print(len(y_pred))
        index=0
        for i in range(1,c):
                if y_pred[j][i] > max_value:
                    max_value = y_pred[j][i]
                    index = i  

        for i in range(c):
            if i == index:
                y_pred[j][i] = 1
                if i == 0:
                    y_predection_col.append('Adelie')
                elif i == 1:
                    y_predection_col.append('Chinstrap')
                else:
                    y_predection_col.append('Gentoo')
            else:
                y_pred[j][i] = 0

    return y_predection_col        

def save_fanction():
    if sigmoid.get() == 1:
        return "sigmoid"
    elif tanh.get():
        return "tanh"
  
print_accuracy = IntVar(window)
def start_training():
    print_accuracy = 0

    trainX, trainY, testX, testY, Y_actualtest, y_actualtrain = SplitData(X, Y)
    trainX, trainY,y_actualtrain = shuffle(trainX, trainY,y_actualtrain)
    testX, testY, Y_actualtest= shuffle(testX, testY, Y_actualtest)
    fun = ''
    if sigmoid.get() == 1:
        fun = 's'
    else:
        fun = 't'
    cells = cellsPerLayer()
    ep = 3
    ett = 0.01
    nLayers = 3
    cels = [4, 3, 2]

    if epochsNum.get() != "":
        ep = int(epochsNum.get())
    if len(cells) != 0:
        cels = []
        [cels.append(i) for i in cells]
    if enter_eta.get() != "":
        ett = float(enter_eta.get())
    if enter_layers.get() != "":
        nLayers = int(enter_layers.get())

    yPred, network = fit(trainX, trainY, ep, ett, biasNum, fun, nLayers, cels) 
    yPred = convertY(yPred,3)
    acc_train = confusion_matrix(y_actualtrain, yPred) # use CM in train accuracy
    print("training accuracy: ", acc_train)
    accPred, y_predection_col = predict(testX, testY, network, nLayers, biasNum, fun)
    # print("ypred ", y_predection_col)
    # print(len(y_predection_col))
    # print("yactual ", Y_actual)
    # print(len(Y_actual))

    acc = confusion_matrix(Y_actualtest, y_predection_col) # adding return value in this fun to return accuracy
    print_accuracy = accPred
    print("testing accuracy: ", acc)
     
    label_accuracy = Label(window, text=print_accuracy)
    label_accuracy.config(font=('Serif', 15))
    label_accuracy.place(x=150, y=452)






strtTrain = Button(window, text="start training", command=lambda t=1: start_training())
strtTrain.config(font=('Serif', 15))
strtTrain.place(x=200, y=390)

label_ = Label(window, text="accuracy: ")
label_.config(font=('Serif', 15))
label_.place(x=30, y=450)
# frame.pack()
window.mainloop()
