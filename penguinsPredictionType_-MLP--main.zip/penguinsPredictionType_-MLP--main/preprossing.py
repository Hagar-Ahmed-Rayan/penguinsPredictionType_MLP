import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
data = pd.read_csv('penguins.csv')


# Preprocessing of test data
X = data

label = LabelEncoder()
X['gender']= label.fit_transform(X['gender'])
X['gender'].unique()


scaler = MinMaxScaler()
cols = ['bill_length_mm','bill_depth_mm','flipper_length_mm', 'body_mass_g']
for i in cols:
    X[i] = scaler.fit_transform(X[[i]])

Data = X.fillna(value='female')
X = Data.iloc[:,1:]
Y = Data.iloc[:,0]
# y_actual = Y
Y = pd.get_dummies(Y)

# Y= pd.DataFrame(Y)
print(Y)

