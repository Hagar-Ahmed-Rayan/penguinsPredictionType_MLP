from unittest import case

import numpy as np
from preprossing import *
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split



def SplitData(X, Y):
    y_actualtest = []
    y_actualtrain = []
    X_train1, X_test1, Y_train1, Y_test1 = train_test_split(
        X[:50], Y[:50], test_size=0.40, shuffle=True, random_state=42)  # 30,20
    X_train2, X_test2, Y_train2, Y_test2 = train_test_split(
        X[50:100], Y[50:100], test_size=0.40, shuffle=True, random_state=42)  # 30,20
    X_train3, X_test3, Y_train3, Y_test3 = train_test_split(
        X[100:], Y[100:], test_size=0.40, shuffle=True, random_state=42)  # 30,20
    trainX = (pd.concat([X_train1, X_train2, X_train3]))
    testX = (pd.concat([X_test1, X_test2, X_test3]))
    trainY = (pd.concat([Y_train1, Y_train2, Y_train3]))

    testY = (pd.concat([Y_test1, Y_test2, Y_test3]))
    for i in range(len(testY)):
        if testY['Adelie'].iloc[i] == 1:
            y_actualtest.append('Adelie')
        elif testY['Chinstrap'].iloc[i] == 1:
            y_actualtest.append('Chinstrap')
        elif testY['Gentoo'].iloc[i] == 1:
            y_actualtest.append('Gentoo')
    for i in range(len(trainY)):
        if trainY['Adelie'].iloc[i] == 1:
            y_actualtrain.append('Adelie')
        elif trainY['Chinstrap'].iloc[i] == 1:
            y_actualtrain.append('Chinstrap')
        elif trainY['Gentoo'].iloc[i] == 1:
            y_actualtrain.append('Gentoo')        

    return trainX, trainY, testX, testY, y_actualtest, y_actualtrain


def sigmoid(x):
    return (1 / (1 + np.exp(-x)))


def sigmoidDeri(x):
    return x * (1.0 - x)


def tanh(x):
    return ((1 - np.exp(-x)) / (1 + np.exp(-x)))


def tanh_deri(y):
    return 1 - y ** 2


def initWieghts(lenX, lenY):
    # init wieght matrix with [x,y] coord
    return [[2 * np.random.random() - 1 for i in range(lenX)] for j in range(lenY)]


r = initWieghts(4, 7)
#print("hhh")


def init_network(n_input, n_hiddenLayers, cellsPerLayer, n_output):
    network = list()
    Layer = []
    # inputLayer = {'wieghts': initWieghts(n_input, n_input), 'bais': initWieghts(n_input, 1)}
    # network.append(inputLayer)
    for i in range(n_hiddenLayers):
        Layer = []
        network.append({'wieghts': initWieghts(n_input, cellsPerLayer[i]), 'bais': initWieghts(cellsPerLayer[i], 1)})
        Layer.append({'wieghts': initWieghts(n_input, cellsPerLayer[i]), 'bais': initWieghts(cellsPerLayer[i], 1)})
        n_input = cellsPerLayer[i]
    outputLayer = {'wieghts': initWieghts(cellsPerLayer[-1], n_output), 'bais': initWieghts(n_output, 1)}
    network.append(outputLayer)
    return network


def fit(X, Y, epochs=3, eta=0.01, bais=0, fun='', hidden_layers=1, cellPerLayer=[]):
    n_input = 5
    n_output = 3

    network = init_network(n_input, hidden_layers, cellPerLayer, n_output)

    for i in range(epochs):
        yPred = []
        inputLayers = []
        for ex in range(X.shape[0]):
            inputLayers, y = forward(X, network, hidden_layers, bais, ex, fun)
            yPred.append(y)

            segmaKforAllLayers = backbroBagation(Y.iloc[ex], yPred[ex], network, fun, hidden_layers, inputLayers)
            network = updateWieghts(segmaKforAllLayers, yPred, inputLayers, network, eta, hidden_layers, cellPerLayer,
                                    bais)
        if i %100==0:
            print("epoch: ", i)                            

    return yPred, network


def forward(X, network, hidden_layers, bais, ex, fun):
    inputsToNextLayer = X.iloc[ex]
    inputLayers = []

    for layer in range(0, hidden_layers + 1):
        hiddenOut = []
        if layer == hidden_layers:
            if bais == 0:
                baisOutput = 0
            v = baisOutput + np.dot(np.asarray(network[-1]['wieghts']), np.asarray(inputsToNextLayer))
            if fun == 's':
                hiddenOut = sigmoid(v)
            elif fun == 't':
                hiddenOut = tanh(v)

            inputLayers.append(inputsToNextLayer)
            inputLayers.append(hiddenOut)

            inputsToNextLayer = hiddenOut
            yPred = hiddenOut
            return inputLayers, yPred

        if bais == 0:
            v = np.dot(np.asarray(network[layer]['wieghts']), np.asarray(inputsToNextLayer))
        else:
            v = network[layer]['bais'] + np.dot(np.asarray(network[layer]['wieghts']), inputsToNextLayer)
        if fun == 's':
            hiddenOut = sigmoid(v)
        elif fun == 't':
            hiddenOut = tanh(v)

        inputLayers.append(inputsToNextLayer)
        inputsToNextLayer = hiddenOut



def backbroBagation(expectedY, predY, network, fun, hidden_layers, inputLayers):
    segmaKforAllLayers = []
    segmaK = []
    for i in reversed(range(hidden_layers + 1)):
        errorList = []
        error = 0

        if i == hidden_layers:  # output layer
            # for cell in range(3):
            if fun == 's':
                error = (np.asarray(expectedY) - np.asarray(predY)) * sigmoidDeri(np.asarray(predY))
            else:
                error = (np.asarray(expectedY) - np.asarray(predY)) * tanh_deri(np.asarray(predY))
            segmaK = error  # f add
        else:


            if fun == 's':
                error = np.dot(np.asarray(segmaK), np.asarray(network[i + 1]['wieghts'])) * sigmoidDeri(
                    inputLayers[i + 1])
            else:
                # 3*2  3*1
                error = np.dot(np.transpose(np.asarray(network[i+1]['wieghts'])), np.asarray(segmaK)) * tanh_deri(inputLayers[i + 1])

            segmaK = error
        segmaKforAllLayers.append( segmaK)
    return segmaKforAllLayers

def updateWieghts(segmaKforAllLayers, yPred, inputLayers, network, eta, hidden_layers, cellPerLayer, bais):
    segmaKforAllLayers.reverse()
    firstLayer =[]
    for i in range(len(inputLayers[0])):
        firstLayer.append(inputLayers[0][i])
    for layer in range(hidden_layers+1):

            if layer == 0:
                network[layer]['wieghts'] = network[layer]['wieghts'] + (eta * np.dot(segmaKforAllLayers[layer].reshape(len(segmaKforAllLayers[layer]),1) , np.asarray(inputLayers[0]).reshape(1, len(inputLayers[0]))))
                if bais != 0:
                    network[layer]['bais'] = network[layer]['bais'] + (eta * segmaKforAllLayers[layer] * 1)
            else:
                network[layer]['wieghts'] = network[layer]['wieghts'] + (
                            eta * np.dot(segmaKforAllLayers[layer].reshape(len(segmaKforAllLayers[layer]),1) , inputLayers[layer].reshape(1,len(inputLayers[layer]))))
                if bais != 0:
                    network[layer]['bais'] = network[layer]['bais'] + (eta * segmaKforAllLayers[layer]* 1)
    return network


def predict(x_test,y_test,network,hidden_layers,bais,activation_func):
    # call forward function with xtest
    true_positive = 0
    y_predection_col = []
    for input_for_each_row in range(x_test.shape[0]):
        input_layers, y_pred = forward(x_test, network, hidden_layers, bais, input_for_each_row, activation_func)
        #     put one to the high probability
        max_value = y_pred[0]
        index = 0
        for i in range(1,len(y_pred)):
            if y_pred[i] > max_value:
                max_value = y_pred[i]
                index = i


        for i in range(len(y_pred)):
            if i == index:
                y_pred[i] = 1
                if i == 0:
                    y_predection_col.append('Adelie')
                elif i == 1:
                    y_predection_col.append('Chinstrap')
                else:
                    y_predection_col.append('Gentoo')
            else:
                y_pred[i] = 0
        # access frst element from each class

        if y_pred[0] == y_test['Adelie'].iloc[input_for_each_row] and y_pred[1] == y_test['Chinstrap'].iloc[input_for_each_row] and \
                    y_pred[2] == y_test['Gentoo'].iloc[input_for_each_row]:
                true_positive += 1
                # print("TP ",true_positive)

    accuracy = true_positive / 60
    print("accuracy in predict fun: ", accuracy)
    # return the output of the network
    return accuracy, y_predection_col 

def confusion_matrix(y_actual,y_pred):
    TA = 0
    TB = 0
    TC = 0
    Eab = 0
    Eac = 0
    Eba = 0
    Ebc = 0
    Eca = 0
    Ecb = 0

    for i in range(len(y_actual)):
        if y_pred[i] == y_actual[i]:
            if y_pred[i] == 'Adelie':
                TA =TA + 1
            elif y_pred[i] == 'Chinstrap':
                TB =TB + 1
            else:
                TC =TC + 1
        else:
            if y_actual[i] == 'Adelie' and y_pred[i] == 'Chinstrap':
                Eab =Eab + 1
            elif y_actual[i] == 'Adelie' and y_pred[i] == 'Gentoo':
                Eac =Eac + 1
            elif y_actual[i] == 'Chinstrap' and y_pred[i] == 'Adelie':
                Eba =Eba + 1
            elif y_actual[i] == 'Chinstrap' and y_pred[i] == 'Gentoo':
                Ebc= Ebc + 1
            elif y_actual[i] == 'Gentoo' and y_pred[i] == 'Adelie':
                Eca =Eca + 1
            elif y_actual[i] == 'Gentoo' and y_pred[i] == 'Chinstrap':
                Ecb =Ecb + 1
    print("Confusion Matrix: ")
    acc = (TA+TB+TC)/len(y_actual)
    cm = pd.DataFrame(
        [[TA, Eab, Eac],
         [Eba, TB, Ebc],
         [Eca, Ecb, TC]],
        columns=[['Predicted', 'Predicted', 'Predicted'],
                 ['Adelie', 'Chinstrap', 'Gentoo']]
    )

    cm.index = [['Actual', 'Actual', 'Actual'],
                ['Adelie', 'Chinstrap', 'Gentoo']]

    print(cm)
    print("Accuracy: ", acc)

    return acc
    # print("accuracy: ",acc)
