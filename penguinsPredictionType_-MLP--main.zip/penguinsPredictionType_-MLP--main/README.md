# PenguinsPredictionType_-MLP-
Penguins Prediction Type by Multi Layer Perceptron.
